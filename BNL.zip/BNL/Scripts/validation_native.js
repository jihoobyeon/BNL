var engine;
var canvas;
var currentScene;
var config;
var justOnce;
var saveResult = true;
var testWidth = 600;
var testHeight = 400;
var generateReferences = false;

// Random replacement
var seed = 1;
Math.random = function () {
    var x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
}

function compare(test, renderData, referenceImage, threshold, errorRatio) {
    var size = renderData.length;
    var referenceData = TestUtils.getImageData(referenceImage);
    var differencesCount = 0;

    for (var index = 0; index < size; index += 4) {
        if (Math.abs(renderData[index] - referenceData[index]) < threshold &&
            Math.abs(renderData[index + 1] - referenceData[index + 1]) < threshold &&
            Math.abs(renderData[index + 2] - referenceData[index + 2]) < threshold) {
            continue;
        }

        if (differencesCount === 0) {
            console.log(`First pixel off at ${index}: Value: (${renderData[index]}, ${renderData[index + 1]}, ${renderData[index] + 2}) - Expected: (${referenceData[index]}, ${referenceData[index + 1]}, ${referenceData[index + 2]}) `);
        }

        referenceData[index] = 255;
        referenceData[index + 1] *= 0.5;
        referenceData[index + 2] *= 0.5;
        differencesCount++;
    }

    if (differencesCount) {
        console.log("Pixel difference: " + differencesCount + " pixels.");
    } else {
        console.log("No pixel difference!");
    }

    let error = (differencesCount * 100) / (size / 4) > errorRatio;

    const width = testWidth / engine.getHardwareScalingLevel();
    const height = testHeight / engine.getHardwareScalingLevel();

    if (error) {
        TestUtils.writePNG(referenceData, width, height, TestUtils.getOutputDirectory() + "/Errors/" + test.referenceImage);
    }
    if (saveResult || error) {
        TestUtils.writePNG(renderData, width, height, TestUtils.getOutputDirectory() + "/Results/" + test.referenceImage);
    }
    return error;
}

function saveRenderedResult(test, renderData) {
    const width = testWidth / engine.getHardwareScalingLevel();
    const height = testHeight / engine.getHardwareScalingLevel();
    TestUtils.writePNG(renderData, width, height, TestUtils.getOutputDirectory() + "/Results/" + test.referenceImage);
    return false; // no error
}

function evaluate(test, resultCanvas, result, referenceImage, index, waitRing, done, compareFunction) {
    engine._engine.getFrameBufferData(function (screenshot) {
        var testRes = true;

        if (!test.onlyVisual) {

            var defaultErrorRatio = 2.5;

            if (compareFunction(test, screenshot, referenceImage, test.threshold || 25, test.errorRatio || defaultErrorRatio)) {
                testRes = false;
                console.log('failed');
            } else {
                testRes = true;
                console.log('validated');
            }
        }

        currentScene.dispose();
        currentScene = null;
        engine.setHardwareScalingLevel(1);

        done(testRes);
    });
}

function processCurrentScene(test, resultCanvas, result, renderImage, index, waitRing, done, compareFunction) {
    currentScene.useConstantAnimationDeltaTime = true;
    var renderCount = test.renderCount || 1;

    currentScene.executeWhenReady(function () {
        if (currentScene.activeCamera && currentScene.activeCamera.useAutoRotationBehavior) {
            currentScene.activeCamera.useAutoRotationBehavior = false;
        }
        engine.runRenderLoop(function () {
            try {
                currentScene.render();
                renderCount--;

                if (renderCount === 0) {
                    engine.stopRenderLoop();
                    evaluate(test, resultCanvas, result, renderImage, index, waitRing, done, compareFunction);
                }
            }
            catch (e) {
                console.error(e);
                done(false);
            }
        });
    });
}

function loadPlayground(test, done, index, referenceImage, compareFunction) {
    if (test.sceneFolder) {
        BABYLON.SceneLoader.Load(config.root + test.sceneFolder, test.sceneFilename, engine, function (newScene) {
            currentScene = newScene;
            processCurrentScene(test, resultCanvas, result, referenceImage, index, waitRing, done, compareFunction);
        },
            null,
            function (loadedScene, msg) {
                console.error(msg);
                done(false);
            });
    }
    else if (test.playgroundId) {
        if (test.playgroundId[0] !== "#" || test.playgroundId.indexOf("#", 1) === -1) {
            test.playgroundId += "#0";
        }

        var snippetUrl = "https://snippet.babylonjs.com";
        var pgRoot = "https://playground.babylonjs.com";

        var retryTime = 500;
        var maxRetry = 5;
        var retry = 0;

        var onError = function () {
            retry++;
            if (retry < maxRetry) {
                setTimeout(function () {
                    loadPG();
                }, retryTime);
            }
            else {
                // Fail the test, something wrong happen
                console.log("Running the playground failed.");
                done(false);
            }
        }

        var loadPG = function () {
            var xmlHttp = new XMLHttpRequest();
            xmlHttp.addEventListener("readystatechange", function () {
                if (xmlHttp.readyState === 4) {
                    try {
                        xmlHttp.onreadystatechange = null;
                        var snippet = JSON.parse(xmlHttp.responseText);
                        var code = JSON.parse(snippet.jsonPayload).code.toString();
                        code = code
                            .replace(/"\/textures\//g, '"' + pgRoot + "/textures/")
                            .replace(/"textures\//g, '"' + pgRoot + "/textures/")
                            .replace(/\/scenes\//g, pgRoot + "/scenes/")
                            .replace(/"scenes\//g, '"' + pgRoot + "/scenes/")
                            .replace(/"\.\.\/\.\.https/g, '"' + "https")
                            .replace("http://", "https://");

                        if (test.replace) {
                            const split = test.replace.split(",");
                            for (let i = 0; i < split.length; i += 2) {
                                const source = split[i].trim();
                                const destination = split[i + 1].trim();
                                code = code.replace(source, destination);
                            }
                        }

                        currentScene = eval(code + "\r\ncreateScene(engine)");
                        var resultCanvas = 0;
                        var result;
                        var waitRing;

                        if (currentScene.then) {
                            // Handle if createScene returns a promise
                            currentScene.then(function (scene) {
                                currentScene = scene;
                                processCurrentScene(test, resultCanvas, result, referenceImage, index, waitRing, done, compareFunction);
                            }).catch(function (e) {
                                console.error(e);
                                onError();
                            })
                        } else {
                            // Handle if createScene returns a scene
                            processCurrentScene(test, resultCanvas, result, referenceImage, index, waitRing, done, compareFunction);
                        }

                    }
                    catch (e) {
                        console.error(e);
                        onError();
                    }
                }
            }, false);
            xmlHttp.onerror = function () {
                console.error("Network error during test load.");
                onError();
            }
            xmlHttp.open("GET", snippetUrl + test.playgroundId.replace(/#/g, "/"));
            xmlHttp.send();
        }
        loadPG();
    } else {
        // Fix references
        if (test.specificRoot) {
            BABYLON.Tools.BaseUrl = config.root + test.specificRoot;
        }

        var request = new XMLHttpRequest();
        request.open('GET', config.root + test.scriptToRun, true);

        request.onreadystatechange = function () {
            if (request.readyState === 4) {
                try {
                    request.onreadystatechange = null;

                    var scriptToRun = request.responseText.replace(/..\/..\/assets\//g, config.root + "/Assets/");
                    scriptToRun = scriptToRun.replace(/..\/..\/Assets\//g, config.root + "/Assets/");
                    scriptToRun = scriptToRun.replace(/\/assets\//g, config.root + "/Assets/");

                    if (test.replace) {
                        var split = test.replace.split(",");
                        for (var i = 0; i < split.length; i += 2) {
                            var source = split[i].trim();
                            var destination = split[i + 1].trim();
                            scriptToRun = scriptToRun.replace(source, destination);
                        }
                    }

                    if (test.replaceUrl) {
                        var split = test.replaceUrl.split(",");
                        for (var i = 0; i < split.length; i++) {
                            var source = split[i].trim();
                            var regex = new RegExp(source, "g");
                            scriptToRun = scriptToRun.replace(regex, config.root + test.rootPath + source);
                        }
                    }

                    currentScene = eval(scriptToRun + test.functionToCall + "(engine)");
                    processCurrentScene(test, resultCanvas, result, renderImage, index, waitRing, done, compareFunction);
                }
                catch (e) {
                    console.error(e);
                    done(false);
                }
            }
        };
        request.onerror = function () {
            console.error("Network error during test load.");
            done(false);
        }

        request.send(null);
    }
}
function runTest(index, done) {
    if (index >= config.tests.length) {
        done(false);
    }

    var test = config.tests[index];
    if (test.onlyVisual || test.excludeFromAutomaticTesting) {
        done(true);
        return;
    }
    if (test.excludedGraphicsApis && test.excludedGraphicsApis.includes(TestUtils.getGraphicsApiName())) {
        done(true);
        return;
    }
    let testInfo = "Running " + test.title;
    console.log(testInfo);
    TestUtils.setTitle(testInfo);

    seed = 1;

    let onLoadFileError = function (request, exception) {
        console.error("Failed to retrieve " + url + ".", exception);
        done(false);
    };
    var onload = function (data, responseURL) {
        if (typeof (data) === "string") {
            throw new Error("Decode Image from string data not yet implemented.");
        }

        var referenceImage = TestUtils.decodeImage(data);
        loadPlayground(test, done, index, referenceImage, compare);

    };

    if (generateReferences) {
        loadPlayground(test, done, index, undefined, saveRenderedResult);
    } else {
        // run test and image comparison
        const url = "app:///ReferenceImages/" + test.referenceImage;
        BABYLON.Tools.LoadFile(url, onload, undefined, undefined, /*useArrayBuffer*/true, onLoadFileError);
    }
}

engine = new BABYLON.NativeEngine();
engine.getCaps().parallelShaderCompile = undefined;

engine.getRenderingCanvas = function () {
    return window;
}

engine.getInputElement = function () {
    return 0;
}

canvas = window;

OffscreenCanvas = function (width, height) {
    return {
        width: width
        , height: height
        , getContext: function (type) {
            return {
                fillRect: function (x, y, w, h) { }
                , measureText: function (text) { return 8; }
                , fillText: function (text, x, y) { }
            };
        }
    };
}

document = {
    createElement: function (type) {
        if (type === "canvas") {
            return new OffscreenCanvas(64, 64);
        }
        return {};
    },
    removeEventListener: function () { }
}

var xhr = new XMLHttpRequest();
xhr.open("GET", "app:///Scripts/config.json", true);

xhr.addEventListener("readystatechange", function () {
    if (xhr.status === 200) {
        config = JSON.parse(xhr.responseText);

        // Run tests
        var index = 0;
        var recursiveRunTest = function (i) {
            runTest(i, function (status) {
                if (!status) {
                    TestUtils.exit(-1);
                    return;
                }
                i++;
                if (justOnce || i >= config.tests.length) {
                    engine.dispose();
                    TestUtils.exit(0);
                    return;
                }
                recursiveRunTest(i);
            });
        }

        recursiveRunTest(index);
    }
}, false);


BABYLON.Tools.LoadFile("https://raw.githubusercontent.com/CedricGuillemet/dump/master/droidsans.ttf", (data) => {
    _native.Canvas.loadTTFAsync("droidsans", data).then(function () {
        _native.RootUrl = "https://playground.babylonjs.com";
        console.log("Starting");
        TestUtils.setTitle("Starting Native Validation Tests");
        TestUtils.updateSize(testWidth, testHeight);
        xhr.send();
    });
}, undefined, undefined, true);
